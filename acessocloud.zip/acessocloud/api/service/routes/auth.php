<?php
 require '../classes/db.php';
 require '../classes/devices.php';
 require '../classes/company.php';
 require '../classes/utils.php';
 $devices = new devices($db_connect);
 $company = new company($db_connect);
 $utils = new utils($db_connect);

     try {
         $jResponse = (object) [];
         $triguer = 0;

//***************

//*********************
         $requestHeaders1 = json_encode(apache_request_headers());

         $body = json_encode($jsonRequest);

         $pst = json_encode($_POST);

         error_log("header da requisição :".$requestHeaders1." *** body::".$body." *** POST".$pst,  0);


         if (isset($jsonRequest->cnpj) && !empty($jsonRequest->cnpj)) {
             if(isset($jsonRequest->login) && !empty($jsonRequest->login)){
                 if(isset($jsonRequest->senha) && !empty($jsonRequest->senha)){
                     if(isset($jsonRequest->deviceid) && !empty($jsonRequest->deviceid)){
                         if(isset($jsonRequest->deviceinfo) && !empty($jsonRequest->deviceinfo)){

                             if($companyId = $company->CompanyExistsBycnpj($jsonRequest->cnpj)){
                                 if($userInfo = $user->login($jsonRequest->login, $jsonRequest->senha) ){



                                     if($devices->checkDevice($jsonRequest->deviceid, $jsonRequest->deviceinfo, $companyId)){//se o equipamento já existir
                                         @$result->token = $devices->getDeviceToken($companyId, $jsonRequest->deviceinfo, $jsonRequest->deviceid);
                                         $result->result = 'success';
                                         $result->companyData = $company->getCompanyInfo($companyId);
                                         $result->cofig = $devices->getDeviceConfigByDevicId($jsonRequest->deviceid);
                                         echo json_encode($result);

                                     } else{
                                         if(@$token->token = $devices->RegistNewDevice($jsonRequest->deviceid, $jsonRequest->deviceinfo, $companyId)){
                                             @$token->result = 'success';
                                             @$result->companyData = $company->getCompanyInfo($companyId);
                                             @$result->cofig = $devices->getDeviceConfigByDevicId($jsonRequest->deviceid);
                                             echo json_encode($token);

                                         }else{}
                                     }
                                 }else{
                                     @$jResponse->result = 'error';
                                     @$jResponse->errorCode = '1004';
                                     $jResponse->message = 'Invalid Credentials';
                                     echo json_encode($jResponse);

                                 }


                             }else{
                                 @$jResponse->result = 'error';
                                 @$jResponse->errorCode = '1003';
                                 $jResponse->message = 'Empresa não existe';
                                 echo json_encode($jResponse);
                             }
                         }else{
                             @$jResponse->result = 'error';
                             @$jResponse->errorCode = '1002';
                             $jResponse->message = 'missing argument deviceinfo';
                             echo json_encode($jResponse);
                         }
                     }else{
                         @$jResponse->result = 'error';
                         @$jResponse->errorCode = '1002';
                         $jResponse->message = 'missing argument deviceid';
                         echo json_encode($jResponse);
                     }

                 }else{
                     @$jResponse->result = 'error';
                     @$jResponse->errorCode = '1002';
                     $jResponse->message = 'missing argument senha';
                     echo json_encode($jResponse);
                 }

             }else{
                 @$jResponse->result = 'error';
                 @$jResponse->errorCode = '1002';
                 apache_request_headers();
                 $jResponse->message = 'missing argument login';
                 echo json_encode($jResponse);
             }

         } else {
             @$jResponse->result = 'error';
             @$jResponse->errorCode = '1002';
             $requestHeaders = apache_request_headers();
             $jResponse->message = 'Missing argument cnpj';
             $jResponse->header = $requestHeaders;

             echo json_encode($jResponse);
      }


     } catch (Exception $ex) {
         echo $ex;
     }
     
     ?>