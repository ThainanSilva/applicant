<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

 
// $from = "nextecnologia <noreply@nextecnologia.com.br>";
// $to = "Thainan Nunes <thainan.silva@nextecnologia.com.br>";
// $subject = "teste de Email";
// $body = "Hi,\n\nHow are you?";

//  $host = "ssl://smtp.zoho.com";
// $port = "465";
// $username = "noreply@nextecnologia.com.br";
// $password = "withoutsenha";


// $headers = array ('From' => $from,
//   'To' => $to,
//   'Subject' => $subject);
// $smtp = Mail::factory('smtp',
//   array ('host' => $host,
//     'port' => $port,
//     'auth' => true,
//     'username' => $username,
//     'password' => $password));

// $mail = $smtp->send($to, $headers, $body);
 
$account="noreply@nextecnologia.com.br";
$password="withoutsenha";
$to="thainan.silva@nextecnologia.com.br";
$from="noreply@nextecnologia.com.br";
$from_name="Vishal G.V";
$msg="<strong>This is a bold text.</strong>"; // HTML message
$subject="HTML message";



 include("../api/phpmailer/class.phpmailer.php");


$mail = new PHPMailer();
$mail->IsSMTP();
$mail->CharSet = 'UTF-8';
$mail->Host = "smtp.zoho.com";
$mail->SMTPAuth= true;
$mail->Port = 465; // Or 587
$mail->Username= $account;
$mail->Password= $password;
$mail->SMTPSecure = 'ssl'; 
$mail->From = $from;
$mail->FromName= $from_name;
$mail->isHTML(true);
$mail->Subject = $subject;
$mail->Body = $msg;
$mail->addAddress($to);

if(!$mail->send()){
 echo "Mailer Error: " . $mail->ErrorInfo;
}else{
 echo "E-Mail has been sent";
}









// error_reporting(E_ALL ^ E_NOTICE ^ E_DEPRECATED ^ E_STRICT);

 

// $host = "ssl://smtp.zoho.com";
// $port = "465";
// $username = "noreply@nextecnologia.com.br";
// $password = "withoutsenha";
 
// $to = "address_form_will_send_TO@example.com";
// $email_from = "noreply@nextecnologia.com.br";
// $email_subject = "Subject Line Here: " ;
// $email_body = "whatever you like" ;
// $email_address = "reply-to@example.com";

// $headers = array ('From' => $email_from, 'To' => $to, 'Subject' => $email_subject, 'Reply-To' => $email_address);
// $smtp = Mail::factory('smtp', array ('host' => $host, 'port' => $port, 'auth' => true, 'username' => $username, 'password' => $password));
// $mail = $smtp->send($to, $headers, $email_body);


// if (PEAR::isError($mail)) {
// echo("<p>" . $mail->getMessage() . "</p>");
// } else {
// echo("<p>Message successfully sent!</p>");
// }