<?php
     
        print $i+2-3+4-2+6-3+8; print'-'; print $i.'12';
    
?>
