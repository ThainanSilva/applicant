<?php
include_once('api/classes/db.php');
include_once('api/isLogged.php');


header('location:app/');
 