<?php
 
 ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 
 
 require './classes/main.php';
 
 $service = new service();
 
 //header('Content-Type: json/application; charset=utf-8');

 $service->post('auth', function($jsonRequest, $contentType){// autenticação
 
     try {
         include './routes/auth.php';
     } catch (Exception $ex) {
         
     }
     
 
 }, 'json'); 




 $service->post('visitors/list', function($jsonRequest, $contentType){ // retorna as configurações
 
     try {
         include './routes/getVisitors.php';
     } catch (Exception $ex) {
         
     }
 
 }, 'json');
 
 
 $service->get('status', function(){// retorna o status do serviço
     @$object->result = 'success';
     $object->status = "ok";
     echo json_encode($object);
     
 }, 'json' );


$service->get('auth', function(){
             $jsonRequest = json_decode(file_get_contents('php://input'));
             echo $jsonRequest;

    echo $_SERVER['REQUEST_URI'];
});
/*
 $service->get('getPerson', function(){
             $jsonRequest = json_decode(file_get_contents('php://input'));
             echo $jsonRequest;
    echo 'wrong access  method, should be Post';
});

    $service->get('/', function( ){

        $return = (object)[];
        $return->result = 'error';
        $return->message = 'wrong access method. User Post instead';

        echo json_encode( $return);
    });


*/
?>