<?php

 /* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

 
 
 require '../classes/db.php';
 
 require '../classes/devices.php';
$devices = new devices($db_connect);
 
 require '../classes/company.php';
$company = new company($db_connect);
 
 require '../classes/utils.php';
$utils = new utils($db_connect);
  

     try {
         if(isset($jsonRequest->token) && !empty($jsonRequest->token)){
             if($devices->CheckDeviceToken($jsonRequest->token)){
                           echo $jsonRequest->token;
             }
          

         }else{
             echo $this->error('1005');
         }
         
     } catch (Exception $ex) {
         echo $ex;
     }
     
     ?>
