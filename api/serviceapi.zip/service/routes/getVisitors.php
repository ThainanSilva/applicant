<?php
/**
 * Created by Thainan Nunes.
 * User: tai_m
 * Date: 28/03/2017
 * Time: 18:04
 */

require '../classes/db.php';
require '../classes/devices.php';
require '../classes/company.php';
require '../classes/utils.php';
require '../classes/visitors.php';
$devices = new devices($db_connect);
$company = new company($db_connect);
$utils = new utils($db_connect);
$visitors = new visitors($db_connect);

//verifica se o token foi enviado na requisição
try {
    if (isset($jsonRequest->token) && !empty($jsonRequest->token)) {
    } else {
        throw new Exception('1005');
    }
} catch (Exception $ex) {
    echo $this->error($ex->getMessage());
}

// verifica se o token é valido no banco
try {
    if ($devices->CheckDeviceToken($jsonRequest->token)) {
    } else {
        throw new Exception('1005');
    }
} catch (Exception $ex) {
    echo $this->error($ex->getMessage());
}

//busca os visitantes no banco de dados e devolve para o
try {
    $companyId=$devices->getCompanyIdByToken($jsonRequest->token);
    $dbvisitors =  array();
    $visitorsrt =  array();
    $dbvisitors =  $visitors->getVisitorsByCompanyforDevice($companyId);

    foreach ($dbvisitors as $key => $value) {
        $counter = 0;
        foreach ($value as $subkey => $subvalue){
            if($subkey === 'dtI' or $subkey === 'dtf' ){
                @$visitorsrt[$key]['schedules'][$counter][$subkey] = $subvalue;
            }elseif ($subkey === 'hri' or $subkey === 'hrf'){
                @$visitorsrt[$key]['schedules'][$counter]['horarios'][$counter][$subkey] = $subvalue;
            }elseif ($subkey == 'picture' ){
                @$visitorsrt[$key][$subkey] = substr($subvalue,23 );
            }
            else{
                @$visitorsrt[$key][$subkey] = $subvalue;
            }
        }
        //next();
    }
            echo json_encode($visitorsrt);

}catch (Exception $exception){
    // throw new Exception( numberCode) sempre fornecer  o código do erro
    echo $this->error($ex->getMessage());
}